# MorningNews
Projet réalisé lors de ma formation chez La Capsule. 
Utilisation d'api, DB et redux entre autre. 
Node.js - React - Express.js

Pour accéder au site localement, depuis la console, veuillez exécuter:
- "npm start" à la racine du dossier pour lancer le serveur
- "npm start" à l'intérieur du dossier "front" pour lancer le site.
